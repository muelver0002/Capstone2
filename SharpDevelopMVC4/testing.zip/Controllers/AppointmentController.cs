﻿using System;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SharpDevelopMVC4.Models;

namespace SharpDevelopMVC4.Controllers
{
	
	public class AppointmentController : Controller
	{
		SdMvc4DbContext _db = new SdMvc4DbContext();
		
		public ActionResult Index()
		{
     		if(Session["user"] != null)
			{
     			if(User.IsInRole("owner"))
     			{
     				var user = Session["user"].ToString();
     				var vetuser = _db.Vetowners.Where(x => x.Username == user ).FirstOrDefault();     			   
     				int VetUserId = vetuser.Id;
     				
     			    List<Appointment> Adminappointment = _db.Appointments.Where(x => x.VetId == VetUserId).ToList();
     			    
     			    return View(Adminappointment);
     			
     			}
     			
			var username = Session["user"].ToString();
			var Vet = _db.Receptionists.Where(x => x.Username == username).FirstOrDefault();		
			int userId = Vet.VetId;
			
			List<Appointment> appointment = _db.Appointments.Where(x => x.VetId == userId).ToList();
			
			return View(appointment);   
			}
			
			return RedirectToAction("Logoff", "Account");
			
			
//			var list = _db.Appointments.ToList();		
//			return View(list);
		}
		
		
		
		public ActionResult Add(int ID)
		{
			

			if(User.IsInRole("customer"))
            {		
				if(Session["user"] != null)
				{
					 ViewBag.Id = ID;
					
					var username = Session["user"].ToString();
					var cus = _db.Customers.Where(x => x.Username == username).FirstOrDefault();
					
					int cusId = cus.Id;
					
					List<Pet> petId = _db.Pets.Where(x => x.OwnersID == cusId).ToList();
					ViewBag.pets = petId;
					
					
					
					Customer customer = _db.Customers.Find(cusId);
					
					return View(customer);
					
					
				
				}
			}
			
			return View();
		
		}
		
		
		[HttpPost]
		public ActionResult Add(Appointment app, int Pet)
		{
			
			var Petinfo = _db.Pets.Where(x => x.Id == Pet).FirstOrDefault();
			  
			app.PetName = Petinfo.PetName;
			app.Color = Petinfo.Color;
			app.Type = Petinfo.Type;
			app.Breed = Petinfo.Breed;
		 
			_db.Appointments.Add(app);
			_db.SaveChanges();
			
			return RedirectToAction("index", "crudsample");
		
		}
	}
}