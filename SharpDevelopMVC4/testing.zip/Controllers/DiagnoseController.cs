﻿using System;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SharpDevelopMVC4.Models;

namespace SharpDevelopMVC4.Controllers
{
	
	public class DiagnoseController : Controller
	{
		SdMvc4DbContext _db = new SdMvc4DbContext();
		public ActionResult Index()
		{
			if(Session["user"] != null)
			{
				if(User.IsInRole("owner"))
				{
					var user1 = Session["user"].ToString();
					var owner = _db.Vetowners.Where(x => x.Username == user1).FirstOrDefault();
					
					int OwnerId = owner.Id;
					
					List<Diagnose> ownerdiagnose = _db.Diagnoses.Where(x => x.Vetid == OwnerId).ToList();
				
					return View(ownerdiagnose);
							
				}
					
					
				var user = Session["user"].ToString();
				var DocUser = _db.Doctors.Where(x => x.Username == user).FirstOrDefault();
				
				int VetId = DocUser.Vetid;
				
				List<Diagnose> Docdiagnose = _db.Diagnoses.Where(x => x.Vetid == VetId).ToList();
				
				return View(Docdiagnose);
			
			}
			
			
			return RedirectToAction("Logoff", "Account");
		}
		
		
		
		public ActionResult Add(int? Id)
		{
			Patient patient = _db.Patients.Find(Id);
				
			
			return View(patient);
		}
		
		[HttpPost]
		public ActionResult Add(Diagnose diagnose)
		{
			
			
			if(Session["user"] != null)
			{
				var user = Session["user"].ToString();
				var doctor = _db.Doctors.Where(x => x.Username == user).FirstOrDefault();
				
				int DocId = doctor.Vetid;
				
				diagnose.Vetid = DocId;
				diagnose.Datetoday = DateTime.Now;
				
				_db.Diagnoses.Add(diagnose);
				_db.SaveChanges();
			
			   return RedirectToAction("index", "Reception");
			
			}
			return RedirectToAction("Logoff", "Account");
		}
	}
}