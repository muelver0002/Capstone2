﻿using System;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SharpDevelopMVC4.Models;

namespace SharpDevelopMVC4.Controllers
{

	public class ReceptionController : Controller
	{
		
		SdMvc4DbContext _db = new SdMvc4DbContext();
		public ActionResult Index()
		{
			if(Session["user"] != null)
			{
				 if(User.IsInRole("owner"))
			     {
				 	var VetUser = Session["user"].ToString();
				 	var AdminVet= _db.Vetowners.Where(x => x.Username == VetUser ).FirstOrDefault();
				 	
				 	int VetId = AdminVet.Id;
				 	List<Patient> addminpatient = _db.Patients.Where(x => x.Vetid == VetId).ToList();
				 	
				 	return View(addminpatient);
				 }
				 if(User.IsInRole("recept"))
				 {
				 	var receptuser = Session["user"].ToString();
				 	var RecepVet =_db.Receptionists.Where(x => x.Username == receptuser).FirstOrDefault();
				 	
				 	int ReceptId = RecepVet.VetId;
				 	
				 	List<Patient> patient1 = _db.Patients.Where(x  => x.Vetid == ReceptId).ToList();
				 		
				 	return View(patient1);
				 }
				
				
				var user = Session["user"].ToString();
				var reception = _db.Doctors.Where(x => x.Username == user).FirstOrDefault();
			    int UserId = reception.Vetid;
				List<Patient> patient = _db.Patients.Where(x => x.Vetid == UserId).ToList();
				
				return View(patient);		
			}
			
				return RedirectToAction("Logoff", "Account");
		}
		
		
		//for Doctor
		public ActionResult Add(int? Id)
		{
			
			Appointment appoinments = _db.Appointments.Find(Id);
			
			return View(appoinments);
		}
		
		[HttpPost]
		public ActionResult Add(Patient patient)
		{
			
			if(Session["user"] != null)
			{
		     var user = Session["user"].ToString();		     
		     var Vet = _db.Receptionists.Where(x => x.Username == user).FirstOrDefault();
		     
		     int Id = Vet.VetId;
		     
		     patient.Datetoday = DateTime.Now;
		     patient.Vetid = Id;
		     
		    _db.Patients.Add(patient);
			_db.SaveChanges();
			
			return RedirectToAction("index", "Appointment");
		     
			}
			

		    return RedirectToAction("Logoff", "Account");
		}
		
		
	
		[HttpGet]
		public ActionResult Addpatient()
		{
		
			return View();
		
		
		}
		
		[HttpPost]
		public ActionResult Addpatient(Patient patient)
		{
			
			if(Session["user"] != null)
			{
				var user = Session["user"].ToString();
				var Vet = _db.Receptionists.Where(x => x.Username == user).FirstOrDefault();
				
				int Receptid = Vet.VetId;
				
				
			    patient.Datetoday = DateTime.Now;
			    patient.Vetid = Receptid;
			    
			    _db.Patients.Add(patient);
			    _db.SaveChanges();
			    
			    return View();
			  
			
			}
			
		    return RedirectToAction("Logoff", "Account");
		
		}
		
		
	}
}